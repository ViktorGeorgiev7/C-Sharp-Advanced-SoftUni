﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations
{
    public class Citizen:Pet,IIdentifiable
    {
        public Citizen(string name,int age,string id,string day,string month,int year) : base(name,day,month,year)
        {
            this.Name = name;
            this.Age = age;
            this.Id = id;
            this.Year = year;
            this.Month = month;
            this.Day = day;
        }
        public int Age { get; set; }
        public string Id { get; set; }
    }
}
