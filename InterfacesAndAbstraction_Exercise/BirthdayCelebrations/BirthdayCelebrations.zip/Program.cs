﻿
using System;
using System.Collections.Generic;
using System.Linq;

namespace BirthdayCelebrations
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            List<Pet> creatures = new List<Pet>();
            char[] delimiters = {' ', '/'};
            while (input != "End")
            {
                string[] placeHolders = input.Split(delimiters,StringSplitOptions.RemoveEmptyEntries);
                switch (placeHolders[0])
                {
                    case "Citizen":
                        creatures.Add(new Citizen(placeHolders[1],int.Parse(placeHolders[2]),placeHolders[3],placeHolders[4],placeHolders[5],int.Parse(placeHolders[6])));
                        break;
                    case "Pet":
                        creatures.Add(new Pet(placeHolders[1],placeHolders[2],placeHolders[3],int.Parse(placeHolders[4])));
                        break;
                    case "Robot"://do nothing as robots do not have a birthdate
                        break;
                }

                input = Console.ReadLine();
            }

            int year = int.Parse(Console.ReadLine());
            creatures = creatures.Where(x => x.Year == year).ToList();
            if (!creatures.Any())
            {
                return;
            }
            foreach (var creature in creatures)
            {
                Console.WriteLine($"{creature.Day}/{creature.Month}/{creature.Year}");
            }
        }
    }
}
