﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    class FamilyCar:Car
    {
        public FamilyCar(int hp,double fuel):base(hp,fuel)
        {
            
        }
    }
}
